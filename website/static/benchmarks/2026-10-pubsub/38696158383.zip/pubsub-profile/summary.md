## Pub/sub diagnostic phases (instrumented, not comparison timings)

Sequential publish acknowledgement then consumption, matching PubSubComparisonBenchmarks. Ack includes client scheduling and the server round trip. AfterAck is residual consumer time, not independent delivery latency: delivery can overlap acknowledgement. Instrumented diagnostics, not latency or allocation comparison results.

| Client | Phase | Mean us | P50 us | P95 us | P99 us | Synchronous reads |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Respire | AckMicroseconds | 201.174 | 198.922 | 261.489 | 288.660 | 1571/5000 |
| Respire | AfterAckMicroseconds | 29.779 | 28.954 | 75.855 | 98.534 | 1571/5000 |
| StackExchange.Redis | AckMicroseconds | 208.874 | 208.029 | 271.217 | 300.361 | 1748/5000 |
| StackExchange.Redis | AfterAckMicroseconds | 28.022 | 22.172 | 75.291 | 99.336 | 1748/5000 |
