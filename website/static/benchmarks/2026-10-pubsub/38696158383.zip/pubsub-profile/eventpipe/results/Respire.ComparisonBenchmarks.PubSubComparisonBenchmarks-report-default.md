
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 7763 2.45GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]   : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  ShortRun : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Job=ShortRun  IterationCount=3  LaunchCount=1  
WarmupCount=3  

 Method                          | Mean     | Error    | StdDev  | Ratio | Completed Work Items | Lock Contentions | Allocated | Alloc Ratio |
-------------------------------- |---------:|---------:|--------:|------:|---------------------:|-----------------:|----------:|------------:|
 StackExchange_PublishAndConsume | 238.2 μs | 17.25 μs | 0.95 μs |  1.00 |               4.4043 |           0.0054 |     672 B |        1.00 |
 Respire_PublishAndConsume       | 248.4 μs | 56.60 μs | 3.10 μs |  1.04 |               3.8389 |           0.0210 |     400 B |        0.60 |
