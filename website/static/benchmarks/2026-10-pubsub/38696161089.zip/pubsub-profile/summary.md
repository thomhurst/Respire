## Pub/sub diagnostic phases (instrumented, not comparison timings)

Sequential publish acknowledgement then consumption, matching PubSubComparisonBenchmarks. Ack includes client scheduling and the server round trip. AfterAck is residual consumer time, not independent delivery latency: delivery can overlap acknowledgement. Instrumented diagnostics, not latency or allocation comparison results.

| Client | Phase | Mean us | P50 us | P95 us | P99 us | Synchronous reads |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Respire | AckMicroseconds | 128.091 | 130.595 | 163.571 | 179.095 | 2389/5000 |
| Respire | AfterAckMicroseconds | 16.943 | 16.632 | 39.922 | 54.796 | 2389/5000 |
| StackExchange.Redis | AckMicroseconds | 157.326 | 159.824 | 186.250 | 203.514 | 3850/5000 |
| StackExchange.Redis | AfterAckMicroseconds | 5.705 | 2.217 | 24.136 | 43.884 | 3850/5000 |
