```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]   : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  ShortRun : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

Job=ShortRun  IterationCount=3  LaunchCount=1  
WarmupCount=3  

```
| Method                          | Mean     | Error    | StdDev  | Ratio | Completed Work Items | Lock Contentions | Allocated | Alloc Ratio |
|-------------------------------- |---------:|---------:|--------:|------:|---------------------:|-----------------:|----------:|------------:|
| StackExchange_PublishAndConsume | 135.2 μs | 10.75 μs | 0.59 μs |  1.00 |               5.2412 |           0.0176 |    1063 B |        1.00 |
| Respire_PublishAndConsume       | 127.3 μs | 20.18 μs | 1.11 μs |  0.94 |               3.6802 |           0.0034 |     400 B |        0.38 |
