```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

```
| Method                          | Mean     | Error   | StdDev  | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
|-------------------------------- |---------:|--------:|--------:|------:|---------------- |--------:|----------:|------------:|
| StackExchange_PublishAndConsume | 125.7 μs | 1.46 μs | 2.19 μs |  1.00 | Baseline        |    0.02 |    1064 B |        1.00 |
| Respire_PublishAndConsume       | 124.7 μs | 0.75 μs | 1.12 μs |  0.99 | Same            |    0.02 |     400 B |        0.38 |
