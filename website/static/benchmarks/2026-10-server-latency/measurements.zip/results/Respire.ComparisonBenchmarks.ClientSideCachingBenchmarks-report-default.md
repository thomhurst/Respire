
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                              | Categories      | Mean      | Error    | StdDev   | Op/s     | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
------------------------------------ |---------------- |----------:|---------:|---------:|---------:|------:|---------------- |--------:|----------:|------------:|
 StackExchange_Exists_ServerRead     | EXISTS hot      |  99.76 μs | 1.884 μs | 2.820 μs | 10,024.4 |  1.00 | Baseline        |    0.04 |     296 B |        1.00 |
 Respire_Exists_ServerRead           | EXISTS hot      | 100.55 μs | 1.510 μs | 2.260 μs |  9,945.1 |  1.01 | Same            |    0.04 |         - |        0.00 |
                                     |                 |           |          |          |          |       |                 |         |           |             |
 StackExchange_Get_ServerRead        | GET hot         | 107.83 μs | 2.711 μs | 4.057 μs |  9,273.9 |  1.00 | Baseline        |    0.05 |     527 B |        1.00 |
 Respire_Get_ServerRead              | GET hot         | 101.60 μs | 1.200 μs | 1.797 μs |  9,843.0 |  0.94 | Same            |    0.04 |      64 B |        0.12 |
                                     |                 |           |          |          |          |       |                 |         |           |             |
 StackExchange_GetMissing_ServerRead | GET missing hot | 109.35 μs | 1.306 μs | 1.955 μs |  9,144.9 |  1.00 | Baseline        |    0.03 |     416 B |        1.00 |
 Respire_GetMissing_ServerRead       | GET missing hot | 102.00 μs | 1.730 μs | 2.589 μs |  9,804.2 |  0.93 | Same            |    0.03 |         - |        0.00 |
                                     |                 |           |          |          |          |       |                 |         |           |             |
 StackExchange_HGet_ServerRead       | HGET hot        | 111.56 μs | 0.974 μs | 1.397 μs |  8,963.6 |  1.00 | Baseline        |    0.02 |     543 B |        1.00 |
 Respire_HGet_ServerRead             | HGET hot        | 103.87 μs | 0.757 μs | 1.109 μs |  9,627.0 |  0.93 | Faster          |    0.02 |      64 B |        0.12 |
