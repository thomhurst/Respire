
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                         | Categories           | Mean       | Error     | StdDev    | Ratio | MannWhitney(5%) | RatioSD | Gen0   | Allocated | Alloc Ratio |
------------------------------- |--------------------- |-----------:|----------:|----------:|------:|---------------- |--------:|-------:|----------:|------------:|
 StackExchange_Exists           | EXISTS               | 102.744 μs | 0.6235 μs | 0.9332 μs |  1.00 | Baseline        |    0.01 |      - |     295 B |        1.00 |
 Respire_Exists                 | EXISTS               |  95.861 μs | 3.9044 μs | 5.8439 μs |  0.93 | Same            |    0.06 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get              | GET                  | 110.771 μs | 1.2219 μs | 1.8289 μs |  1.00 | Baseline        |    0.02 |      - |     502 B |        1.00 |
 Respire_Get                    | GET                  |  99.934 μs | 1.8565 μs | 2.7787 μs |  0.90 | Faster          |    0.03 |      - |      48 B |        0.10 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_GetLong          | GET long             | 109.751 μs | 0.8271 μs | 1.2123 μs |  1.00 | Baseline        |    0.02 |      - |     415 B |        1.00 |
 Respire_GetLong                | GET long             | 100.312 μs | 2.3864 μs | 3.5718 μs |  0.91 | Faster          |    0.03 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get_SteadyState  | GET x100 sequential  |  85.980 μs | 0.6770 μs | 0.9709 μs |  1.00 | Baseline        |    0.02 |      - |     338 B |        1.00 |
 Respire_Get_SteadyState        | GET x100 sequential  |  80.970 μs | 0.3863 μs | 0.5415 μs |  0.94 | Same            |    0.01 |      - |      50 B |        0.15 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get_Pipelined    | GET x200 pipelined   |   1.514 μs | 0.0385 μs | 0.0552 μs |  1.00 | Baseline        |    0.05 | 0.0146 |     289 B |        1.00 |
 Respire_Get_Pipelined          | GET x200 pipelined   |   1.407 μs | 0.0072 μs | 0.0103 μs |  0.93 | Same            |    0.03 | 0.0024 |      49 B |        0.17 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get_Concurrent   | GET x50 concurrent   |   3.324 μs | 0.0523 μs | 0.0783 μs |  1.00 | Baseline        |    0.03 | 0.0098 |     291 B |        1.00 |
 Respire_Get_Concurrent         | GET x50 concurrent   |   3.055 μs | 0.0191 μs | 0.0286 μs |  0.92 | Faster          |    0.02 |      - |      52 B |        0.18 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_HGet             | HGET                 | 109.106 μs | 1.4243 μs | 1.9966 μs |  1.00 | Baseline        |    0.03 |      - |     520 B |        1.00 |
 Respire_HGet                   | HGET                 |  99.962 μs | 1.8843 μs | 2.8203 μs |  0.92 | Faster          |    0.03 |      - |      48 B |        0.09 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_HSet             | HSET                 | 104.983 μs | 1.0589 μs | 1.5849 μs |  1.00 | Baseline        |    0.02 |      - |     328 B |        1.00 |
 Respire_HSet                   | HSET                 | 104.186 μs | 1.6189 μs | 2.4232 μs |  0.99 | Same            |    0.03 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Incr             | INCR                 | 100.479 μs | 2.0274 μs | 3.0345 μs |  1.00 | Baseline        |    0.04 |      - |     296 B |        1.00 |
 Respire_Incr                   | INCR                 |  98.713 μs | 2.4484 μs | 3.6647 μs |  0.98 | Same            |    0.05 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_LPushLPop        | LPUSH+LPOP           | 207.913 μs | 3.7299 μs | 5.4673 μs |  1.00 | Baseline        |    0.04 |      - |     760 B |        1.00 |
 Respire_LPushLPop              | LPUSH+LPOP           | 200.581 μs | 1.3785 μs | 1.9770 μs |  0.97 | Same            |    0.03 |      - |     256 B |        0.34 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Ping             | PING                 |  97.065 μs | 2.1578 μs | 3.1628 μs |  1.00 | Baseline        |    0.05 |      - |     303 B |        1.00 |
 Respire_Ping                   | PING                 |  93.805 μs | 3.4263 μs | 5.0223 μs |  0.97 | Same            |    0.06 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Ping_SteadyState | PING x100 sequential |  82.237 μs | 0.9688 μs | 1.3894 μs |  1.00 | Baseline        |    0.02 |      - |     242 B |       1.000 |
 Respire_Ping_SteadyState       | PING x100 sequential |  78.143 μs | 0.6845 μs | 1.0245 μs |  0.95 | Same            |    0.02 |      - |       2 B |       0.008 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_SAdd             | SADD                 |  96.493 μs | 4.1928 μs | 6.2755 μs |  1.00 | Baseline        |    0.09 |      - |     312 B |        1.00 |
 Respire_SAdd                   | SADD                 | 100.800 μs | 1.8099 μs | 2.7089 μs |  1.05 | Same            |    0.07 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_10KB         | SET 10KB             | 117.864 μs | 0.7227 μs | 1.0365 μs |  1.00 | Baseline        |    0.01 |      - |     312 B |        1.00 |
 Respire_Set_10KB               | SET 10KB             | 120.382 μs | 1.1587 μs | 1.6984 μs |  1.02 | Same            |    0.02 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_Small        | SET 13B              | 103.948 μs | 0.8217 μs | 1.2044 μs |  1.00 | Baseline        |    0.02 |      - |     311 B |        1.00 |
 Respire_Set_Small              | SET 13B              | 103.051 μs | 1.3332 μs | 1.9954 μs |  0.99 | Same            |    0.02 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_1KB          | SET 1KB              | 105.679 μs | 1.0368 μs | 1.5197 μs |  1.00 | Baseline        |    0.02 |      - |     312 B |        1.00 |
 Respire_Set_1KB                | SET 1KB              | 101.637 μs | 2.1314 μs | 3.1902 μs |  0.96 | Same            |    0.03 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_SteadyState  | SET x100 sequential  |  86.249 μs | 0.5078 μs | 0.7119 μs |  1.00 | Baseline        |    0.01 |      - |     250 B |       1.000 |
 Respire_Set_SteadyState        | SET x100 sequential  |  83.516 μs | 0.5746 μs | 0.8422 μs |  0.97 | Same            |    0.01 |      - |       2 B |       0.008 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_SetDel           | SET+DEL              | 207.056 μs | 1.5008 μs | 2.2463 μs |  1.00 | Baseline        |    0.02 |      - |     648 B |        1.00 |
 Respire_SetDel                 | SET+DEL              | 192.682 μs | 1.2953 μs | 1.9388 μs |  0.93 | Faster          |    0.01 |      - |     200 B |        0.31 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_SIsMember        | SISMEMBER            |  98.654 μs | 1.6609 μs | 2.4860 μs |  1.00 | Baseline        |    0.04 |      - |     312 B |        1.00 |
 Respire_SIsMember              | SISMEMBER            | 101.225 μs | 1.6174 μs | 2.3708 μs |  1.03 | Same            |    0.03 |      - |         - |        0.00 |
