
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                          | Mean     | Error   | StdDev  | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
-------------------------------- |---------:|--------:|--------:|------:|---------------- |--------:|----------:|------------:|
 StackExchange_PublishAndConsume | 154.5 μs | 3.85 μs | 5.76 μs |  1.00 | Baseline        |    0.05 |    1046 B |        1.00 |
 Respire_PublishAndConsume       | 174.0 μs | 1.30 μs | 1.95 μs |  1.13 | Slower          |    0.05 |     399 B |        0.38 |
