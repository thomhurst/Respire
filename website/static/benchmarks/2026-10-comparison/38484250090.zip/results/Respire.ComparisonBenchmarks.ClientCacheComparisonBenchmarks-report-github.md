```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

```
| Method                           | Missing | Mean     | Error   | StdDev  | Ratio | MannWhitney(5%) | Gen0   | Allocated | Alloc Ratio |
|--------------------------------- |-------- |---------:|--------:|--------:|------:|---------------- |-------:|----------:|------------:|
| **StackExchange_Get_ClientCacheHit** | **False**   | **191.0 ns** | **1.23 ns** | **1.80 ns** |  **1.00** | **Baseline**        | **0.0067** |     **112 B** |        **1.00** |
| Respire_Get_ClientCacheHit       | False   | 114.9 ns | 0.15 ns | 0.20 ns |  0.60 | Faster          |      - |         - |        0.00 |
|                                  |         |          |         |         |       |                 |        |           |             |
| **StackExchange_Get_ClientCacheHit** | **True**    | **135.6 ns** | **0.29 ns** | **0.41 ns** |  **1.00** | **Baseline**        |      **-** |         **-** |          **NA** |
| Respire_Get_ClientCacheHit       | True    | 117.3 ns | 0.22 ns | 0.31 ns |  0.86 | Faster          |      - |         - |          NA |
