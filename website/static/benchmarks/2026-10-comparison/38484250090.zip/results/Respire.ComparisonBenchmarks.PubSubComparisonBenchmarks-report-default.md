
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                          | Mean     | Error   | StdDev  | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
-------------------------------- |---------:|--------:|--------:|------:|---------------- |--------:|----------:|------------:|
 StackExchange_PublishAndConsume | 117.1 μs | 2.14 μs | 3.14 μs |  1.00 | Baseline        |    0.04 |    1056 B |        1.00 |
 Respire_PublishAndConsume       | 130.8 μs | 1.22 μs | 1.83 μs |  1.12 | Slower          |    0.03 |     396 B |        0.38 |
