
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                         | Categories           | Mean       | Error     | StdDev    | Ratio | MannWhitney(5%) | RatioSD | Gen0   | Allocated | Alloc Ratio |
------------------------------- |--------------------- |-----------:|----------:|----------:|------:|---------------- |--------:|-------:|----------:|------------:|
 StackExchange_Exists           | EXISTS               | 113.468 μs | 0.5487 μs | 0.8043 μs |  1.00 | Baseline        |    0.01 |      - |     518 B |        1.00 |
 Respire_Exists                 | EXISTS               |  97.716 μs | 2.2846 μs | 3.4195 μs |  0.86 | Faster          |    0.03 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get              | GET                  | 113.737 μs | 1.5128 μs | 2.2174 μs |  1.00 | Baseline        |    0.03 |      - |     718 B |        1.00 |
 Respire_Get                    | GET                  |  90.781 μs | 2.2935 μs | 3.4329 μs |  0.80 | Faster          |    0.03 |      - |      48 B |        0.07 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_GetLong          | GET long             | 114.927 μs | 0.6654 μs | 0.9960 μs |  1.00 | Baseline        |    0.01 |      - |     632 B |        1.00 |
 Respire_GetLong                | GET long             |  95.943 μs | 1.7497 μs | 2.4529 μs |  0.83 | Faster          |    0.02 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get_SteadyState  | GET x100 sequential  |  92.215 μs | 2.3050 μs | 3.4499 μs |  1.00 | Baseline        |    0.05 |      - |     205 B |        1.00 |
 Respire_Get_SteadyState        | GET x100 sequential  |  81.109 μs | 1.2698 μs | 1.9006 μs |  0.88 | Faster          |    0.04 |      - |      50 B |        0.24 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get_Pipelined    | GET x200 pipelined   |   1.716 μs | 0.0652 μs | 0.0975 μs |  1.00 | Baseline        |    0.08 | 0.0293 |     505 B |        1.00 |
 Respire_Get_Pipelined          | GET x200 pipelined   |   1.373 μs | 0.0052 μs | 0.0075 μs |  0.80 | Faster          |    0.05 | 0.0024 |      49 B |        0.10 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Get_Concurrent   | GET x50 concurrent   |   3.681 μs | 0.0644 μs | 0.0924 μs |  1.00 | Baseline        |    0.04 | 0.0293 |     501 B |        1.00 |
 Respire_Get_Concurrent         | GET x50 concurrent   |   3.037 μs | 0.0094 μs | 0.0135 μs |  0.83 | Faster          |    0.02 |      - |      52 B |        0.10 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_HGet             | HGET                 | 116.696 μs | 0.8607 μs | 1.2882 μs |  1.00 | Baseline        |    0.02 |      - |     718 B |        1.00 |
 Respire_HGet                   | HGET                 | 101.495 μs | 2.1170 μs | 3.1686 μs |  0.87 | Faster          |    0.03 |      - |      48 B |        0.07 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_HSet             | HSET                 | 115.521 μs | 1.0345 μs | 1.5483 μs |  1.00 | Baseline        |    0.02 |      - |     520 B |        1.00 |
 Respire_HSet                   | HSET                 | 103.962 μs | 2.9925 μs | 4.4790 μs |  0.90 | Faster          |    0.04 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Incr             | INCR                 | 115.415 μs | 0.9373 μs | 1.3739 μs |  1.00 | Baseline        |    0.02 |      - |     519 B |        1.00 |
 Respire_Incr                   | INCR                 |  98.503 μs | 2.6063 μs | 3.9010 μs |  0.85 | Faster          |    0.03 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_LPushLPop        | LPUSH+LPOP           | 225.154 μs | 1.8793 μs | 2.8129 μs |  1.00 | Baseline        |    0.02 |      - |     858 B |        1.00 |
 Respire_LPushLPop              | LPUSH+LPOP           | 198.477 μs | 1.5328 μs | 2.1983 μs |  0.88 | Faster          |    0.01 |      - |     256 B |        0.30 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Ping             | PING                 | 112.531 μs | 0.8281 μs | 1.2394 μs |  1.00 | Baseline        |    0.02 |      - |     541 B |        1.00 |
 Respire_Ping                   | PING                 |  92.371 μs | 2.7828 μs | 4.1651 μs |  0.82 | Faster          |    0.04 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Ping_SteadyState | PING x100 sequential |  90.173 μs | 0.9416 μs | 1.3802 μs |  1.00 | Baseline        |    0.02 |      - |     133 B |        1.00 |
 Respire_Ping_SteadyState       | PING x100 sequential |  79.714 μs | 0.9307 μs | 1.3643 μs |  0.88 | Faster          |    0.02 |      - |       2 B |        0.02 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_SAdd             | SADD                 | 113.370 μs | 0.6944 μs | 1.0393 μs |  1.00 | Baseline        |    0.01 |      - |     519 B |        1.00 |
 Respire_SAdd                   | SADD                 |  98.382 μs | 1.5969 μs | 2.3902 μs |  0.87 | Faster          |    0.02 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_10KB         | SET 10KB             | 131.878 μs | 0.7220 μs | 1.0807 μs |  1.00 | Baseline        |    0.01 |      - |     432 B |        1.00 |
 Respire_Set_10KB               | SET 10KB             | 118.639 μs | 0.4647 μs | 0.6664 μs |  0.90 | Faster          |    0.01 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_Small        | SET 13B              | 114.985 μs | 1.7170 μs | 2.5699 μs |  1.00 | Baseline        |    0.03 |      - |     520 B |        1.00 |
 Respire_Set_Small              | SET 13B              |  99.405 μs | 2.5217 μs | 3.7743 μs |  0.86 | Faster          |    0.04 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_1KB          | SET 1KB              | 119.035 μs | 0.7005 μs | 1.0485 μs |  1.00 | Baseline        |    0.01 |      - |     432 B |        1.00 |
 Respire_Set_1KB                | SET 1KB              | 102.708 μs | 2.3269 μs | 3.4828 μs |  0.86 | Faster          |    0.03 |      - |         - |        0.00 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_Set_SteadyState  | SET x100 sequential  |  95.635 μs | 1.1188 μs | 1.6746 μs |  1.00 | Baseline        |    0.02 |      - |     109 B |        1.00 |
 Respire_Set_SteadyState        | SET x100 sequential  |  81.584 μs | 1.1433 μs | 1.6397 μs |  0.85 | Faster          |    0.02 |      - |       2 B |        0.02 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_SetDel           | SET+DEL              | 219.893 μs | 2.2582 μs | 3.2386 μs |  1.00 | Baseline        |    0.02 |      - |     729 B |        1.00 |
 Respire_SetDel                 | SET+DEL              | 191.925 μs | 1.5237 μs | 2.2335 μs |  0.87 | Faster          |    0.02 |      - |     200 B |        0.27 |
                                |                      |            |           |           |       |                 |         |        |           |             |
 StackExchange_SIsMember        | SISMEMBER            | 113.863 μs | 0.7926 μs | 1.1863 μs |  1.00 | Baseline        |    0.01 |      - |     520 B |        1.00 |
 Respire_SIsMember              | SISMEMBER            | 100.462 μs | 1.9337 μs | 2.8943 μs |  0.88 | Faster          |    0.03 |      - |         - |        0.00 |
