
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
AMD EPYC 9V74 2.60GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                              | Categories      | Mean         | Error       | StdDev      | Median       | Op/s        | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
------------------------------------ |---------------- |-------------:|------------:|------------:|-------------:|------------:|------:|---------------- |--------:|----------:|------------:|
 StackExchange_Exists_ServerRead     | EXISTS hot      | 113,988.5 ns |   798.58 ns | 1,195.27 ns | 114,182.0 ns |     8,772.8 | 1.000 | Baseline        |    0.01 |     583 B |        1.00 |
 Respire_Exists_ServerRead           | EXISTS hot      | 100,314.6 ns | 1,844.13 ns | 2,760.21 ns | 101,052.7 ns |     9,968.6 | 0.880 | Faster          |    0.03 |         - |        0.00 |
 Respire_Exists_ClientCacheHit       | EXISTS hot      |     275.4 ns |     1.05 ns |     1.47 ns |     275.8 ns | 3,630,990.7 | 0.002 | Faster          |    0.00 |         - |        0.00 |
                                     |                 |              |             |             |              |             |       |                 |         |           |             |
 StackExchange_Get_ServerRead        | GET hot         | 115,558.1 ns |   943.43 ns | 1,412.09 ns | 116,065.1 ns |     8,653.7 | 1.000 | Baseline        |    0.02 |     808 B |        1.00 |
 Respire_Get_ServerRead              | GET hot         | 101,525.9 ns | 1,524.58 ns | 2,234.72 ns | 101,752.1 ns |     9,849.7 | 0.879 | Faster          |    0.02 |      64 B |        0.08 |
 Respire_Get_ClientCacheHit          | GET hot         |     114.0 ns |     0.22 ns |     0.32 ns |     114.0 ns | 8,768,549.9 | 0.001 | Faster          |    0.00 |         - |        0.00 |
                                     |                 |              |             |             |              |             |       |                 |         |           |             |
 StackExchange_GetMissing_ServerRead | GET missing hot | 114,271.2 ns |   968.42 ns | 1,449.48 ns | 114,707.7 ns |     8,751.1 | 1.000 | Baseline        |    0.02 |     695 B |        1.00 |
 Respire_GetMissing_ServerRead       | GET missing hot |  97,328.2 ns | 3,006.88 ns | 4,500.56 ns |  99,327.5 ns |    10,274.5 | 0.852 | Faster          |    0.04 |         - |        0.00 |
 Respire_GetMissing_ClientCacheHit   | GET missing hot |     117.1 ns |     0.89 ns |     1.25 ns |     116.1 ns | 8,539,395.4 | 0.001 | Faster          |    0.00 |         - |        0.00 |
                                     |                 |              |             |             |              |             |       |                 |         |           |             |
 StackExchange_HGet_ServerRead       | HGET hot        | 115,272.8 ns |   842.33 ns | 1,180.84 ns | 115,607.9 ns |     8,675.1 | 1.000 | Baseline        |    0.01 |     807 B |        1.00 |
 Respire_HGet_ServerRead             | HGET hot        | 103,605.2 ns | 1,607.10 ns | 2,355.66 ns | 103,650.7 ns |     9,652.0 | 0.899 | Faster          |    0.02 |      64 B |        0.08 |
 Respire_HGet_ClientCacheHit         | HGET hot        |     319.8 ns |     4.34 ns |     6.09 ns |     317.8 ns | 3,127,310.9 | 0.003 | Faster          |    0.00 |         - |        0.00 |
