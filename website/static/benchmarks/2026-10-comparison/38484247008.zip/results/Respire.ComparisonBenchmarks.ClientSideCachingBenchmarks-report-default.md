
BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

 Method                              | Categories      | Mean         | Error     | StdDev      | Median       | Op/s        | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
------------------------------------ |---------------- |-------------:|----------:|------------:|-------------:|------------:|------:|---------------- |--------:|----------:|------------:|
 StackExchange_Exists_ServerRead     | EXISTS hot      | 109,232.4 ns | 573.16 ns |   840.14 ns | 109,385.1 ns |     9,154.8 | 1.000 | Baseline        |    0.01 |     296 B |        1.00 |
 Respire_Exists_ServerRead           | EXISTS hot      | 108,891.0 ns | 857.81 ns | 1,283.92 ns | 109,088.9 ns |     9,183.5 | 0.997 | Same            |    0.01 |         - |        0.00 |
 Respire_Exists_ClientCacheHit       | EXISTS hot      |     269.9 ns |   3.57 ns |     5.24 ns |     268.4 ns | 3,705,738.2 | 0.002 | Faster          |    0.00 |         - |        0.00 |
                                     |                 |              |           |             |              |             |       |                 |         |           |             |
 StackExchange_Get_ServerRead        | GET hot         | 109,178.1 ns | 627.74 ns |   920.14 ns | 108,969.5 ns |     9,159.3 | 1.000 | Baseline        |    0.01 |     528 B |        1.00 |
 Respire_Get_ServerRead              | GET hot         | 108,594.1 ns | 744.94 ns | 1,114.99 ns | 108,906.6 ns |     9,208.6 | 0.995 | Same            |    0.01 |      64 B |        0.12 |
 Respire_Get_ClientCacheHit          | GET hot         |     125.8 ns |   1.01 ns |     1.35 ns |     126.8 ns | 7,949,295.4 | 0.001 | Faster          |    0.00 |         - |        0.00 |
                                     |                 |              |           |             |              |             |       |                 |         |           |             |
 StackExchange_GetMissing_ServerRead | GET missing hot | 108,988.4 ns | 780.66 ns | 1,144.28 ns | 109,247.3 ns |     9,175.3 | 1.000 | Baseline        |    0.01 |     416 B |        1.00 |
 Respire_GetMissing_ServerRead       | GET missing hot | 108,265.8 ns | 650.90 ns |   974.24 ns | 108,385.0 ns |     9,236.5 | 0.993 | Same            |    0.01 |         - |        0.00 |
 Respire_GetMissing_ClientCacheHit   | GET missing hot |     128.0 ns |   0.71 ns |     1.03 ns |     128.3 ns | 7,813,241.2 | 0.001 | Faster          |    0.00 |         - |        0.00 |
                                     |                 |              |           |             |              |             |       |                 |         |           |             |
 StackExchange_HGet_ServerRead       | HGET hot        | 110,662.0 ns | 999.26 ns | 1,433.11 ns | 111,018.9 ns |     9,036.5 | 1.000 | Baseline        |    0.02 |     543 B |        1.00 |
 Respire_HGet_ServerRead             | HGET hot        | 107,937.9 ns | 871.69 ns | 1,304.71 ns | 107,902.8 ns |     9,264.6 | 0.976 | Same            |    0.02 |      64 B |        0.12 |
 Respire_HGet_ClientCacheHit         | HGET hot        |     321.2 ns |   1.38 ns |     1.97 ns |     321.5 ns | 3,113,235.5 | 0.003 | Faster          |    0.00 |         - |        0.00 |
