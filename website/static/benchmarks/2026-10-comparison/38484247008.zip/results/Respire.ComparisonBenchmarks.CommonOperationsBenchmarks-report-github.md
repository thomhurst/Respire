```

BenchmarkDotNet v0.15.8, Linux Ubuntu 24.04.5 LTS (Noble Numbat)
INTEL XEON PLATINUM 8573C 2.30GHz, 1 CPU, 4 logical and 2 physical cores
.NET SDK 10.0.402
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4
  Job-IDGKZI : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v4

IterationCount=15  LaunchCount=2  WarmupCount=10  

```
| Method                         | Categories           | Mean       | Error     | StdDev    | Median     | Ratio | MannWhitney(5%) | RatioSD | Allocated | Alloc Ratio |
|------------------------------- |--------------------- |-----------:|----------:|----------:|-----------:|------:|---------------- |--------:|----------:|------------:|
| StackExchange_Exists           | EXISTS               | 109.080 μs | 0.5449 μs | 0.7986 μs | 109.023 μs |  1.00 | Baseline        |    0.01 |     296 B |        1.00 |
| Respire_Exists                 | EXISTS               | 108.120 μs | 0.8404 μs | 1.2578 μs | 108.195 μs |  0.99 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Get              | GET                  | 108.916 μs | 0.7565 μs | 1.1089 μs | 108.918 μs |  1.00 | Baseline        |    0.01 |     504 B |        1.00 |
| Respire_Get                    | GET                  | 108.447 μs | 0.6875 μs | 1.0291 μs | 108.495 μs |  1.00 | Same            |    0.01 |      48 B |        0.10 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_GetLong          | GET long             | 108.991 μs | 0.4405 μs | 0.6457 μs | 109.098 μs |  1.00 | Baseline        |    0.01 |     416 B |        1.00 |
| Respire_GetLong                | GET long             | 108.388 μs | 0.4209 μs | 0.6169 μs | 108.420 μs |  0.99 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Get_SteadyState  | GET x100 sequential  |  93.943 μs | 0.9317 μs | 1.3657 μs |  94.153 μs |  1.00 | Baseline        |    0.02 |     338 B |        1.00 |
| Respire_Get_SteadyState        | GET x100 sequential  |  89.151 μs | 1.0186 μs | 1.5247 μs |  89.497 μs |  0.95 | Same            |    0.02 |      50 B |        0.15 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Get_Pipelined    | GET x200 pipelined   |   1.870 μs | 0.0870 μs | 0.1302 μs |   1.936 μs |  1.01 | Baseline        |    0.10 |     289 B |        1.00 |
| Respire_Get_Pipelined          | GET x200 pipelined   |   1.630 μs | 0.0117 μs | 0.0172 μs |   1.630 μs |  0.88 | Faster          |    0.07 |      49 B |        0.17 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Get_Concurrent   | GET x50 concurrent   |   3.439 μs | 0.0454 μs | 0.0679 μs |   3.437 μs |  1.00 | Baseline        |    0.03 |     291 B |        1.00 |
| Respire_Get_Concurrent         | GET x50 concurrent   |   3.061 μs | 0.0253 μs | 0.0378 μs |   3.067 μs |  0.89 | Faster          |    0.02 |      52 B |        0.18 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_HGet             | HGET                 | 108.667 μs | 0.8045 μs | 1.2041 μs | 108.747 μs |  1.00 | Baseline        |    0.02 |     520 B |        1.00 |
| Respire_HGet                   | HGET                 | 108.143 μs | 0.6267 μs | 0.9379 μs | 108.400 μs |  1.00 | Same            |    0.01 |      48 B |        0.09 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_HSet             | HSET                 | 109.674 μs | 0.5902 μs | 0.8834 μs | 109.743 μs |  1.00 | Baseline        |    0.01 |     328 B |        1.00 |
| Respire_HSet                   | HSET                 | 109.850 μs | 0.4958 μs | 0.7420 μs | 109.837 μs |  1.00 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Incr             | INCR                 | 109.459 μs | 0.5544 μs | 0.8299 μs | 109.636 μs |  1.00 | Baseline        |    0.01 |     296 B |        1.00 |
| Respire_Incr                   | INCR                 | 108.765 μs | 0.5386 μs | 0.7894 μs | 108.812 μs |  0.99 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_LPushLPop        | LPUSH+LPOP           | 207.979 μs | 1.2407 μs | 1.7794 μs | 207.706 μs |  1.00 | Baseline        |    0.01 |     760 B |        1.00 |
| Respire_LPushLPop              | LPUSH+LPOP           | 205.466 μs | 1.7639 μs | 2.6402 μs | 204.472 μs |  0.99 | Same            |    0.01 |     256 B |        0.34 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Ping             | PING                 | 108.415 μs | 0.5876 μs | 0.8795 μs | 108.574 μs |  1.00 | Baseline        |    0.01 |     303 B |        1.00 |
| Respire_Ping                   | PING                 | 108.190 μs | 0.5336 μs | 0.7987 μs | 108.281 μs |  1.00 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Ping_SteadyState | PING x100 sequential |  92.409 μs | 0.9367 μs | 1.4020 μs |  92.316 μs |  1.00 | Baseline        |    0.02 |     242 B |       1.000 |
| Respire_Ping_SteadyState       | PING x100 sequential |  88.859 μs | 1.1063 μs | 1.6558 μs |  88.674 μs |  0.96 | Same            |    0.02 |       2 B |       0.008 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_SAdd             | SADD                 | 109.482 μs | 0.6475 μs | 0.9691 μs | 109.576 μs |  1.00 | Baseline        |    0.01 |     312 B |        1.00 |
| Respire_SAdd                   | SADD                 | 108.965 μs | 0.6074 μs | 0.9091 μs | 109.103 μs |  1.00 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Set_10KB         | SET 10KB             | 115.088 μs | 1.3919 μs | 2.0402 μs | 114.311 μs |  1.00 | Baseline        |    0.02 |     312 B |        1.00 |
| Respire_Set_10KB               | SET 10KB             | 112.989 μs | 0.8238 μs | 1.2330 μs | 113.157 μs |  0.98 | Same            |    0.02 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Set_Small        | SET 13B              | 110.387 μs | 0.6958 μs | 1.0414 μs | 110.553 μs |  1.00 | Baseline        |    0.01 |     312 B |        1.00 |
| Respire_Set_Small              | SET 13B              | 109.257 μs | 0.6119 μs | 0.9159 μs | 109.485 μs |  0.99 | Same            |    0.01 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Set_1KB          | SET 1KB              | 110.148 μs | 0.8972 μs | 1.3429 μs | 110.427 μs |  1.00 | Baseline        |    0.02 |     312 B |        1.00 |
| Respire_Set_1KB                | SET 1KB              | 109.930 μs | 0.7464 μs | 1.0940 μs | 110.101 μs |  1.00 | Same            |    0.02 |         - |        0.00 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_Set_SteadyState  | SET x100 sequential  |  96.416 μs | 1.4405 μs | 2.1561 μs |  96.086 μs |  1.00 | Baseline        |    0.03 |     250 B |       1.000 |
| Respire_Set_SteadyState        | SET x100 sequential  |  91.513 μs | 1.0724 μs | 1.5719 μs |  91.292 μs |  0.95 | Same            |    0.03 |       2 B |       0.008 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_SetDel           | SET+DEL              | 205.198 μs | 1.0812 μs | 1.4434 μs | 205.314 μs |  1.00 | Baseline        |    0.01 |     648 B |        1.00 |
| Respire_SetDel                 | SET+DEL              | 201.940 μs | 1.0721 μs | 1.5715 μs | 201.835 μs |  0.98 | Same            |    0.01 |     200 B |        0.31 |
|                                |                      |            |           |           |            |       |                 |         |           |             |
| StackExchange_SIsMember        | SISMEMBER            | 109.688 μs | 0.4727 μs | 0.7075 μs | 109.598 μs |  1.00 | Baseline        |    0.01 |     312 B |        1.00 |
| Respire_SIsMember              | SISMEMBER            | 108.239 μs | 0.7833 μs | 1.1233 μs | 108.478 μs |  0.99 | Same            |    0.01 |         - |        0.00 |
